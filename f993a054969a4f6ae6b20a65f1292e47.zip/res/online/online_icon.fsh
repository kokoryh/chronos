void main() {
  float alpha = min(texture2D(cron_texture, cron_tex_coord).a, 0.35);
  cron_output = alpha * vec4(1.0, 1.0, 1.0, 1.0);
}
