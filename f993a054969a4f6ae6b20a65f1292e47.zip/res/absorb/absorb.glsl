#define TRANSFORM_TEX(uv) vec2((uv).x, (uv).y)

float UniformNoise(float noise, float strength)
{
    return (noise * 2.0 - 1.0) * strength;
}

float Remap(float value, vec2 from, vec2 to)
{
    float factor = (value - from.x) / (from.y - from.x);
    return to.x + factor * (to.y - to.x);
}

vec3 TransformToRetangle(vec3 pos)
{
    return pos * vec3(_world_unit, _world_unit / _aspect_ratio, _world_unit);
}

vec3 TransfromToScreen(vec3 pos)
{
    return pos / vec3(_world_unit, _world_unit / _aspect_ratio, _world_unit);
}

float Pow2(float x)
{
    return x*x;
}

float Smoothstep(float x)
{
    x = clamp(x, 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}

float Saturate(float x)
{
    return clamp(x, 0.0, 1.0);
}

void main()
{
    float time = max(_time + _time_offset, 0.0);
    time *= _time_scale;

    vec2 uv = cron_tex_coord;

    vec3 pos = TransformToRetangle(vec3(uv, 0.0));
    vec3 major_focus = TransformToRetangle(_major_focus);
    vec3 minor_focus = TransformToRetangle(_minor_focus);

    vec3 diff = pos - major_focus;
    float radius = length(diff);
    vec3 direction = normalize(diff);

    float focus_length = length(major_focus - minor_focus);
    float major_length = radius + length(pos - minor_focus);
    radius = ((major_length - focus_length) / 2.0);

    float corner = atan(direction.x, direction.y);
    corner += time * _radial_dist_velocity;
    float radial_dist_ampt_noise = UniformNoise(texture(_noise_sampler, TRANSFORM_TEX(uv + _radial_dist_ampt_noise_velocity * time)).r, _radial_dist_ampt_noise_strength);
    float radial_dist_phase_noise = UniformNoise(texture(_noise_sampler, TRANSFORM_TEX(uv + _radial_dist_phase_noise_velocity * time)).g, _radial_dist_phase_noise_strength);
    float radial_dist_offset_noise = UniformNoise(texture(_noise_sampler, TRANSFORM_TEX(uv + _radial_dist_offset_noise_velocity * time)).b, _radial_dist_offset_noise_strength);
    float radial_dist = (_radial_dist_ampt + radial_dist_ampt_noise) * sin(corner * _radial_dist_freq + radial_dist_phase_noise);
    radial_dist += radial_dist_offset_noise;
    radial_dist *= _world_unit;
    radial_dist *= clamp(time * _radial_dist_time_scale, 0.0, 1.0);
    {
        float radius_affect = 1.0 - Saturate(radius / _radial_dist_radius_range);
        radius_affect = pow(radius_affect, _radial_dist_radius_order);
        radial_dist *= radius_affect;

        float time_affect = Saturate(time / _radial_dist_time_range);
        time_affect = pow(time_affect, _radial_dist_time_order - 1.0) * (_radial_dist_time_order - (_radial_dist_time_order - 1.0) * time_affect);
        radial_dist *= time_affect;
    }

    float line_distance = 1.0;
    {
        float radius_affect = pow(pow(_gravitation, _gravitation_order) + pow(radius, _gravitation_order), 1.0/_gravitation_order) - radius;
        line_distance *= radius_affect;

        float time_affect = Saturate(time / _gravitation_time_range);
        time_affect = pow(time_affect, _gravitation_time_order - 1.0) * (_gravitation_time_order - (_gravitation_time_order - 1.0) * time_affect);
        line_distance *= time_affect;
    }
    line_distance += radial_dist;

    float angle = _angle_velocity;
    {
        float radius_affect = 1.0 - Saturate(radius / _angle_velocity_radius_range);
        radius_affect = pow(radius_affect, _angle_velocity_radius_order);
        angle *= radius_affect;

        float time_affect = Saturate(time / _angle_velocity_time_range);
        time_affect = pow(time_affect, _angle_velocity_time_order - 1.0) * (_angle_velocity_time_order - (_angle_velocity_time_order - 1.0) * time_affect);
        angle *= time_affect;
    }

    vec3 rotated_position = vec3(0.0);
    node_vector_rotate_axis_angle(direction * line_distance, vec3(0.0), vec3(0.0,0.0,-1.0), angle, vec3(0.0), 1.0, rotated_position);

    vec3 result_pos = pos + rotated_position;

    vec2 result_uv = TransfromToScreen(result_pos).xy;

    float pixel_noise = UniformNoise(texture(_noise_sampler, TRANSFORM_TEX(uv + _pixel_noise_velocity)).a, _pixel_noise_strength);
    pixel_noise *= clamp(time * _pixel_noise_time_scale, 0.0, 1.0);
    {
        float radius_affect = 1.0 - Saturate(radius / _pixel_noise_radius_range);
        radius_affect = pow(radius_affect, _pixel_noise_radius_order);
        pixel_noise *= radius_affect;

        float time_affect = Saturate(time / _pixel_noise_time_range);
        time_affect = pow(time_affect, _pixel_noise_time_order - 1.0) * (_pixel_noise_time_order - (_pixel_noise_time_order - 1.0) * time_affect);
        pixel_noise *= time_affect;
    }

    result_uv += pixel_noise;

    if (any(bvec2(floor(result_uv)))) {
        cron_output = vec4(0,0,0,0);
    } 
    else 
    {

        cron_output = texture(cron_texture, TRANSFORM_TEX(result_uv));
        cron_output *= cron_color_mix.a;
    }

    //cron_output = texture(cron_texture, TRANSFORM_TEX(uv)) * vec4(1,0,0,1);
}