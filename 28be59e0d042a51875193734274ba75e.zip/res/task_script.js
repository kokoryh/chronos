const __cronc_redirector_script_impl__ = cron.Data.createFromFile("src/danmaku/business/demand/entry_point/@cronc.worker.task_script.js");
[eval][0](__cronc_redirector_script_impl__.getSubString());